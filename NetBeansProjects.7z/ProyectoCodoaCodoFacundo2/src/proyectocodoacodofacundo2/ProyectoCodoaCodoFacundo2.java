/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectocodoacodofacundo2;

/**
 *
 * @author PC16
 */
public class ProyectoCodoaCodoFacundo2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int natural;
        natural=10;
            if(natural<=15){
                System.out.println("Es Verdadero");
            }else{
                System.out.println("Es Falso");
            }
    }
    
}
